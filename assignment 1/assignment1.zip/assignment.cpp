#include <iostream>
#include <fstream>
using namespace std;

int main()
{

  ifstream fin;
  fin.open("hello-world.txt", ios::in);

  char my_character ;
  int number_of_lines = -1;
  int number_of_bytes = 0;

  	while (!fin.eof() )
    {
  	fin.get(my_character);
  	cout << my_character;
  		if (my_character == '\n')
      {
  			number_of_lines++;
  		}
      number_of_bytes++;
  	}

    ifstream myfile;
    myfile.open("hello-world.txt");
    int number_of_words = -1;
    char words[1000];
    while (!myfile.eof())
    {
      myfile>> words;
      number_of_words++;
    }
    cout << "NUMBER OF LINES: " << number_of_lines << endl;
    cout << "NUMBER OF BYTES: " << (number_of_bytes - number_of_lines)<< endl;
    cout << "NUMBER OF WORDS: " << number_of_words << endl;
  fin.close();
  myfile.close();

  return 0;
}
